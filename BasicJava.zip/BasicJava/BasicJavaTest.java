public class BasicJavaTest {
    public static void main(String[] args) {
        BasicJava basic = new BasicJava();
        // basic.print255();
        // basic.odds255();
        // basic.sum255();
        int[] x = {1,3,16,7,9,13,2};
        // basic.iterateArr(x);
        // basic.max(x);
        // basic.average(x);
        // basic.arrOdds();
        // basic.greaterY(x,8);
        // basic.square(x);
        // basic.delNegatives(x);
        // basic.minMaxAvg(x);
        basic.shift(x);
    }
}