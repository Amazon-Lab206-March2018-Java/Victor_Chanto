package com.umanav.roster.models;

public class Roster {

}
