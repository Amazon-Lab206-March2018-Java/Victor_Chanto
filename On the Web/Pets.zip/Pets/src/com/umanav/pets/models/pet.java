package com.umanav.pets.models;

public interface pet {
	String showAffection();
}
