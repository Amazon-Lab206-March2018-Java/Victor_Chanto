import java.util.Random;
public class PuzzleJavaTest {    
    public static void main(String[] args) {
        PuzzleJava test = new PuzzleJava();
        // int[] x = {3,5,1,2,7,9,8,13,25,32};
        // System.out.println(test.greaterTen(x));
        // String[] y = {"Nancy", "Jinichi", "Fujibayashi", "Momochi", "Ishikawa"};
        // System.out.println(test.names(y));
        // String a = "abcdefghijklmnopqrstuvwxyz";
        // System.out.println(test.shuffle(a));
        // System.out.println(test.ran10());
        // System.out.println(test.RanSort10());
        // test.RandString();
        System.out.println(test.RandString10());
    }
}