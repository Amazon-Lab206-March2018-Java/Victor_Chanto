package com.umanav.calculator;

public interface Operators {
	void performOperation();
	void getResults();
}
