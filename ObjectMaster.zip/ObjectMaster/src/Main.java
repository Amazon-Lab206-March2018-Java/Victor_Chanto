public class Main {

	public static void main(String[] args) {
		Human Javier = new Human();
		Human Alejandro = new Human();
		Alejandro.attack(Javier);
		System.out.println(Javier.getHealth());
	}

}
