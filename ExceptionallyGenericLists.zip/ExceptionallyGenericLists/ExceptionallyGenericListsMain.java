public class ExceptionallyGenericListsMain {    
    public static void main(String[] args) {
        ExceptionallyGenericLists exceptions = new ExceptionallyGenericLists();
        exceptions.exceptions();
    }
}