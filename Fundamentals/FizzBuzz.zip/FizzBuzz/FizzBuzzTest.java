public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz x = new FizzBuzz();
        System.out.println(x.fizzBuzz(5));
        System.out.println(x.fizzBuzz(3));
        System.out.println(x.fizzBuzz(10));
        System.out.println(x.fizzBuzz(6));
        System.out.println(x.fizzBuzz(15));
        System.out.println(x.fizzBuzz(20));
    }
}