public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean x = new Pythagorean();
        System.out.println(x.calculateHypotenuse(4,3));
    }
}