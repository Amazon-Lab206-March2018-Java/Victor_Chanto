public class MapHashmatiqueMain {    
    public static void main(String[] args) {
        MapHashmatique trackList = new MapHashmatique();
        trackList.trackList();
    }
}