public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("My name is Victor Chanto");
        System.out.println("I am 24 years old");
        System.out.println("My Hometown is San Marcos, San Jose, Costa Rica");
    }
}
