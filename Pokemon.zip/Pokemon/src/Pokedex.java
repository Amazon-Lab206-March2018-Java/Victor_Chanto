
public class Pokedex extends AbstractPokemon {
	public static void pokemonInfo(Pokemon pokemon) {
		PokemonInterface.pokemonInfo(pokemon);
	}

}
