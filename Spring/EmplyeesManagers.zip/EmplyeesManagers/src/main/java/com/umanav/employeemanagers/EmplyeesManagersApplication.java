package com.umanav.employeemanagers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmplyeesManagersApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmplyeesManagersApplication.class, args);
	}
}
