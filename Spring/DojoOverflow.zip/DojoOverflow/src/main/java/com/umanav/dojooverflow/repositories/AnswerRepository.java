package com.umanav.dojooverflow.repositories;

import org.springframework.data.repository.CrudRepository;

import com.umanav.dojooverflow.models.Answer;

public interface AnswerRepository extends CrudRepository<Answer, Long> {

}
